class Product:
    # The below block is a method in Python class commonly known as the initializer or constructor.Its purpose is to set the initial values for the attributes or variables of a class instance at the time of creation
    def __init__(self, csv_line):
        # Strip will remove empty spaces from the columns and split function split values with needed seperator
        columns = csv_line.strip().split(',')

        # self keyword is an instance of a class
        # It is mainly used for modifying and accessing the attributes
        # columns[] accesses the elements based on index from the list columns.
        self.Order = columns[0]
        self.File_Type = columns[1]
        self.SKU_number = columns[2]
        self.SoldFlag = columns[3]
        self.SoldCount = columns[4]
        self.MarketingType = columns[5]
        self.ReleaseNumber = columns[6]
        self.New_Release_Flag = columns[7]
        self.StrengthFactor = columns[8]
        # Below code is used for type conversion
        self.PriceReg = float(columns[9])
        self.ReleaseYear = columns[10]
        self.ItemCount = columns[11]
        self.LowUserPrice = float(columns[12])
        self.LowNetPrice = float(columns[13])	

    # It is a Special Method it provides a representation of an object.When you call print() or str() it returns the values from below block
    def __str__(self):
        return f"Order: {self.Order}, File_Type: {self.File_Type}, SKU_number: {self.SKU_number}, SoldFlag: {self.SoldFlag}, SoldCount: {self.SoldCount}, MarketingType: {self.MarketingType}, ReleaseNumber: {self.ReleaseNumber}, New_Release_Flag: {self.New_Release_Flag}, StrengthFactor: {self.StrengthFactor}, PriceReg: {self.PriceReg}, ReleaseYear: {self.ReleaseYear}, ItemCount: {self.ItemCount}, LowUserPrice: {self.LowUserPrice}, LowNetPrice: {self.LowNetPrice}"

csv_line = "2,Historical,1737127,0,0,D,15,1,682743,44.99,2015,8,28.97,31.84"
# It is Creating the Instance of a Product class by calling it's constructor, storing in product_instance and passing the parameter
product_instance = Product(csv_line) # Object Creation
print("Order:", product_instance.Order)
print("File_Type:", product_instance.File_Type)
print("SKU_number:", product_instance.SKU_number)
print("SoldFlag:", product_instance.SoldFlag)
print("SoldCount:", product_instance.SoldCount)
print("MarketingType:", product_instance.MarketingType)
print("ReleaseNumber:", product_instance.ReleaseNumber)
print("New_Release_Flag:", product_instance.New_Release_Flag)
print("StrengthFactor:", product_instance.StrengthFactor)
print("PriceReg:", product_instance.PriceReg)
print("ReleaseYear:", product_instance.ReleaseYear)
print("ItemCount:", product_instance.ItemCount)
print("LowUserPrice:", product_instance.LowUserPrice)
print("LowNetPrice:", product_instance.LowNetPrice)
# It calls the Special method from the above
print(product_instance)