import csv
import json
import pickle

class Product:
    # The below block is a method in Python class commonly known as the initializer or constructor.Its purpose is to set the initial values for the attributes or variables of a class instance at the time of creation
    def __init__(self, csv_line):
        # Strip will remove empty spaces from the columns and split function split values with needed seperator
        columns = csv_line.strip().split(',')

        # self keyword is an instance of a class
        # It is mainly used for modifying and accessing the attributes
        # columns[] accesses the elements based on index from the list columns.
        self.Order = columns[0]
        self.File_Type = columns[1]
        self.SKU_number = columns[2]
        self.SoldFlag = columns[3]
        self.SoldCount = columns[4]
        self.MarketingType = columns[5]
        self.ReleaseNumber = columns[6]
        self.New_Release_Flag = columns[7]
        self.StrengthFactor = columns[8]
        # Below code is used for type conversion
        self.PriceReg = float(columns[9])
        self.ReleaseYear = columns[10]
        self.ItemCount = columns[11]
        self.LowUserPrice = float(columns[12])
        self.LowNetPrice = float(columns[13])	

    # It is a Special Method it provides a representation of an object.When you call print() or str() it returns the values from below block
    def __str__(self):
        return f"Order: {self.Order}, File_Type: {self.File_Type}, SKU_number: {self.SKU_number}, SoldFlag: {self.SoldFlag}, SoldCount: {self.SoldCount}, MarketingType: {self.MarketingType}, ReleaseNumber: {self.ReleaseNumber}, New_Release_Flag: {self.New_Release_Flag}, StrengthFactor: {self.StrengthFactor}, PriceReg: {self.PriceReg}, ReleaseYear: {self.ReleaseYear}, ItemCount: {self.ItemCount}, LowUserPrice: {self.LowUserPrice}, LowNetPrice: {self.LowNetPrice}"

csv_line = "2,Historical,1737127,0,0,D,15,1,682743,44.99,2015,8,28.97,31.84"
# It is Creating the Instance of a Product class by calling it's constructor, storing in product_instance and passing the parameter
product_instance = Product(csv_line) # Object Creation
print("Order:", product_instance.Order)
print("File_Type:", product_instance.File_Type)
print("SKU_number:", product_instance.SKU_number)
print("SoldFlag:", product_instance.SoldFlag)
print("SoldCount:", product_instance.SoldCount)
print("MarketingType:", product_instance.MarketingType)
print("ReleaseNumber:", product_instance.ReleaseNumber)
print("New_Release_Flag:", product_instance.New_Release_Flag)
print("StrengthFactor:", product_instance.StrengthFactor)
print("PriceReg:", product_instance.PriceReg)
print("ReleaseYear:", product_instance.ReleaseYear)
print("ItemCount:", product_instance.ItemCount)
print("LowUserPrice:", product_instance.LowUserPrice)
print("LowNetPrice:", product_instance.LowNetPrice)


import csv

class DataManager:
    # The below block is a method in Python class commonly known as the initializer or constructor.Its purpose is to set the values for the attributes or variables of a class instance at the time of creation
    def __init__(self, Given_File):
        self.Given_File = Given_File # Input File
        self.filtered_data = []

    def Filtered_Dataset(self):
        # try and except are used for exception handling used for handle errors and exceptions that might occur during the execution of the code. 
        try:
            with open(self.Given_File, 'r', newline='') as csvfile:
                # DictReader reads a CSV file and Each row is read as a dictionary where the keys are the column headers and the values are the corresponding values in that row.
                reader = csv.DictReader(csvfile)
                for row in reader:
                    self.filtered_data.append(row)
        # If file not present it executes below block
        except FileNotFoundError:
            print(f"File not found: {self.Given_File}")

    # 
    def Formatted_Table_To_Display(self):
        if not self.filtered_data:
            print("No data is Available")
            return

        # Below code passing the dictionary comprehension where key represents the column names and values represents the length of each column name
        ColumnSize = {key: len(key) for key in self.filtered_data[0].keys()}
        for row in self.filtered_data:
            for key, value in row.items():
                # It is comparing the length of a column name with the length of a value represented as a string, and it returns the maximum of these two lengths.
                ColumnSize[key] = max(ColumnSize[key], len(str(value)))

        for key, w in ColumnSize.items():
            print(f"{key:{w}}", end=' | ')
        print()

        for row in self.filtered_data:
            for key, w in ColumnSize.items():
                print(f"{str(row[key]):{w}}", end=' | ')
            print()
        
    def sort_data(self, column_name):
        # Sorted is a built in function in python it sorts an iterable
        # lambda function extracts the value of the specified column_name for each dictionary x in the list
        self.filtered_data = sorted(self.filtered_data, key=lambda x: x[column_name])
    
    def filter_data(self, condition_column, condition_value):
        # Below statement is List Comprehension it provides concise compared to other function, given the parameters with the given condition
        self.filtered_data = [row for row in self.filtered_data if row.get(condition_column) == condition_value]
    
    def Filtered_Sorted_Data_to_Json(self, file_path):
        if not self.filtered_data:
            print("No data")
            return
        
        # Below block opens the file specified by the File in write mode ('w')
        # json.dump() is a function provided by the Python json module, enabling the transformation of a Python object into a JSON-formatted stream
        try:
            with open(file_path, 'w') as json_file:
                json.dump(self.filtered_data, json_file, indent=4)
            print("Filtered and sorted data saved to JSON successfully.")
        except Exception as e:
            print(f"error has occurred when saving to JSON: {str(e)}")

    def save_products_to_pickle(self, products, file_path):
        try:
            with open(file_path, 'wb') as PickleFile:
                pickle.dump(products, PickleFile)
            print("Products saved to pickle successfully.")
        except Exception as e:
            print(f"An error occurred while saving to pickle: {str(e)}")

    def load_products_from_pickle(self, file_path):
        try:
            # Below block opens the file specified by the File in read in binary mode ('rb').
            with open(file_path, 'rb') as PickleFile:
                # pickle.load() is a function provided by the Python pickle module, used to deserialize a previously serialized Python object from a binary file
                products = pickle.load(PickleFile)
            print("Products loaded from the pickle.")
            return products
        # If any issue it executes below block and also done type conversion
        except Exception as e:
            print(f"An error occurred while loading from pickle: {str(e)}")
            return None
    
if __name__ == "__main__":
    # It is Creating the Instance of a Product class by calling it's constructor, storing in Given File and passing the parameter
    Given_File = 'SalesKaggle3_With_Removed_Columns.csv'  # Given file
    data_manager = DataManager(Given_File)
    data_manager.Filtered_Dataset()
    data_manager.Formatted_Table_To_Display()
    data_manager.sort_data("StrengthFactor")
    data_manager.Formatted_Table_To_Display()
    data_manager.filter_data("SoldFlag", "1")
    data_manager.Formatted_Table_To_Display()
    data_manager.Filtered_Sorted_Data_to_Json('Filtered_Sorted_Data.json')
    data_manager.save_products_to_pickle(product_instance, 'Product.pkl')
    loaded_products = data_manager.load_products_from_pickle('Product.pkl')
