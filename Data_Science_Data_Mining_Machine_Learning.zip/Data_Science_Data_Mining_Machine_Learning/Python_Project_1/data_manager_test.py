from data_manager import DataManager

# Replace with your actual file path
file_path = 'SalesKaggle3_With_Removed_Columns.csv'

# Instantiate the DataManager
data_manager = DataManager(file_path)

# Load the filtered dataset
data_manager.Filtered_Dataset()

# Display the Actual data in a formatted table
print("Actual Data:")
data_manager.Formatted_Table_To_Display()
sorted_data = data_manager.sort_data("StrengthFactor")

# Display the sorted data
print("Sorted Data by StrengthFactor:")
for item in sorted_data:
    print(item)
