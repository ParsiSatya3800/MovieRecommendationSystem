import csv
# Defining Functions with it's Parameters
def SKU_numbers(sales_file, strength_factor):
    SKU_numbers = []

    # Below block opens the file specified by the Given_File in read mode ('r').
    # Afterward, a CSV reader instance (csv_reader) is established using the csv.reader function
    with open(sales_file, 'r') as fp:
        csv_reader = csv.reader(fp)
        header = next(csv_reader)

        # Header was skipping beacuse it contains Columns in first row
        # Below statement is List Comprehension it provides concise compared to other function
        # row[8] defines the stength factor
        SKU_numbers = [row[2] for row in csv_reader if float(row[8]) > strength_factor]

    return SKU_numbers

sales_file = 'SalesKaggle3.csv' # Given File
strength_factor = 400.0 # Any Random Value

FilteredSkuNumbers = SKU_numbers(sales_file, strength_factor) # Calling Function and passing Parameters

print("SKU Numbers for products with StrengthFactor Which is Greater than {}: {}".format(strength_factor, FilteredSkuNumbers))
