import csv

class DataManager:
    # The below block is a method in Python class commonly known as the initializer or constructor.Its purpose is to set the values for the attributes or variables of a class instance at the time of creation
    def __init__(self, Given_File):
        self.Given_File = Given_File # Input File
        self.filtered_data = []

    def Filtered_Dataset(self):
        # try and except are used for exception handling used for handle errors and exceptions that might occur during the execution of the code. 
        try:
            with open(self.Given_File, 'r', newline='') as csvfile:
                # DictReader reads a CSV file and Each row is read as a dictionary where the keys are the column headers and the values are the corresponding values in that row.
                reader = csv.DictReader(csvfile)
                for row in reader:
                    self.filtered_data.append(row)
        # If file not present it executes below block
        except FileNotFoundError:
            print(f"File not found: {self.Given_File}")

    # 
    def Formatted_Table_To_Display(self):
        if not self.filtered_data:
            print("No data is Available")
            return

        # Below code passing the dictionary comprehension where key represents the column names and values represents the length of each column name
        ColumnSize = {key: len(key) for key in self.filtered_data[0].keys()}
        for row in self.filtered_data:
            for key, value in row.items():
                # It is comparing the length of a column name with the length of a value represented as a string, and it returns the maximum of these two lengths.
                ColumnSize[key] = max(ColumnSize[key], len(str(value)))

        for key, w in ColumnSize.items():
            print(f"{key:{w}}", end=' | ')
        print()

        for row in self.filtered_data:
            for key, w in ColumnSize.items():
                print(f"{str(row[key]):{w}}", end=' | ')
            print()
        
    def sort_data(self, column_name):
        # Sorted is a built in function in python it sorts an iterable
        # lambda function extracts the value of the specified column_name for each dictionary x in the list
        self.filtered_data = sorted(self.filtered_data, key=lambda x: x[column_name])
    
    def filter_data(self, condition_column, condition_value):
        # Below statement is List Comprehension it provides concise compared to other function, given the parameters with the given condition
        self.filtered_data = [row for row in self.filtered_data if row.get(condition_column) == condition_value]
    
if __name__ == "__main__":
    Given_File = 'SalesKaggle3_With_Removed_Columns.csv'  # Given file
    data_manager = DataManager(Given_File)
    data_manager.Filtered_Dataset()
    data_manager.Formatted_Table_To_Display()
    data_manager.sort_data("StrengthFactor")
    data_manager.Formatted_Table_To_Display()
    data_manager.filter_data("SoldFlag", "1")
    data_manager.Formatted_Table_To_Display()
