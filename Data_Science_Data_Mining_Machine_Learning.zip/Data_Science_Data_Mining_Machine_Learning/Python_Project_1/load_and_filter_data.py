import csv

Given_File = 'SalesKaggle3.csv' # Input File
Filtered_Columns_File = 'SalesKaggle3_With_Removed_Columns.csv' # Output File

Remove_Column_With_Indexes = [0, 1, 6, 7, 9] # Columns to remove Based on indexes of columns from Input File

# Below block opens the file specified by the Given_File in read mode ('r').
# Afterward, a CSV reader instance (csv_reader) is established using the csv.reader function, enabling it to read the CSV file indicated by input_file.

with open(Given_File, 'r') as input_file:
    csv_reader = csv.reader(input_file)
    RowstoWrite = []

    for row in csv_reader:
        FilteredRow = [row[i] for i in range(len(row)) if i not in Remove_Column_With_Indexes] # It Removes the specified columns in the given index
        RowstoWrite.append(FilteredRow)

# Write the Updated data to a new Ouput CSV file
# Below block opens the file specified by the Given_File in write mode ('w').
# csv.writer CSV module that provides functionality to write to CSV files. It allows you to write rows of data into a CSV file.
with open(Filtered_Columns_File, 'w', newline='') as output_file:
    csv_writer = csv.writer(output_file)
    csv_writer.writerows(RowstoWrite)

print("Updated Columns :", Filtered_Columns_File)
