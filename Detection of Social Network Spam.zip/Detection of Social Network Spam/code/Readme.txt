Install Python 3.6


And then open terminal and enter

pip install -r requirements.txt